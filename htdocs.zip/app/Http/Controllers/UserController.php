<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\UserModel;
class UserController extends Controller{
	function index(){
		$list = UserModel::all();
		return view('admin.user',['list'=>$list]);
	}
	function user_edit(){
		return view('admin.user_edit');
	}
}
