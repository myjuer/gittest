<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class UserModel extends Model{
	protected $table = 'user';
	/*function getAll(){
		$data = UserModel::all();
		return $data;
	}*/
}
